import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-kanban',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div>
      <h2>Kanban Board</h2>
      <!-- Kanban board implementation will go here -->
    </div>
  `
})
export class KanbanComponent {}
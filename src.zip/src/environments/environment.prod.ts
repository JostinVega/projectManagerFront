export const environment = {
  production: true,
  apiUrl: 'https://api.project-management-app.com/api'
};